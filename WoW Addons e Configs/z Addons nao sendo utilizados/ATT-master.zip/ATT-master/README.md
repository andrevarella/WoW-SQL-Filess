# ATT - alternative for PartyAbilityBars

#### Install
##### After download from github - rename folder into "ATT"

#### demo
1. ![Demo 1](https://i.imgur.com/54shcSt.png)
2. ![Demo 2](https://i.imgur.com/0UDHl2G.png)

###### support me
* https://streamlabs.com/qbjw/tip
