# sArena for 3.3.5 version (backported from WoD)

#### Advanced settings
* now ArenaEnemyCastBar can be moveable
* now ArenaEnemyCastBar can be set size or width
* now can be set padding between arena frames

#### Install
##### After download from github - rename folder into "sArena"

#### demo
1. ![Demo 1](https://i.imgur.com/TuUC1ms.png)
2. ![Demo 2](https://i.imgur.com/QC3B0mJ.png)

###### support me
* https://streamlabs.com/qbjw/tip
