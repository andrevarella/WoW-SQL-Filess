# PartyCooldownTracker

Code for addon WeakAuras


![Alt Text](https://media.giphy.com/media/vFKqnCdLPNOKc/giphy.gif)
