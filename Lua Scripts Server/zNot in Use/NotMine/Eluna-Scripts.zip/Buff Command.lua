-- Eluna Lua Engine
local function BuffCommand(event, player, msg, Type, lang)
    if(msg:lower() == "#buff") then
        player:AddAura(48074, player)
        player:AddAura(48170, player)
        player:AddAura(43223, player)
        player:AddAura(36880, player)
        player:AddAura(467, player)
        player:AddAura(48469, player)
        player:AddAura(48162, player)
        player:SendBroadcastMessage("You have been buffed, enjoy!")
    end
    return false
end

RegisterPlayerEvent(18, BuffCommand)