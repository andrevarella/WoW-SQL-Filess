function Gnome_onUse (pUnit, Event, pMisc)
pMisc:Teleport (0, -4966.618652, 705.545776, 249.368668)
end
RegisterGameObjectEvent (55001, 2, 'Gnome_onUse')
