function MindBlastOne(effectIndex, Spell)
        local plr = Spell:GetCaster()
        if(plr:HasSpell(15257) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 3)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15331) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 2)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15332) == true) then
                if(Spell:GetSpellState(3) == true) then
                        plr:CastSpell(15258)
                                                 end
                                                end
                                        end
                                end
                        end
                end
        end
end
end
 
function MindBlastTwo(effectIndex, Spell)
        local plr = Spell:GetCaster()
        if(plr:HasSpell(15257) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 3)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15331) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 2)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15332) == true) then
                if(Spell:GetSpellState(3) == true) then
                        plr:CastSpell(15258)
                                                end
                                                end
                                        end
                                end
                        end
                end
        end
end
end
 
function MindBlastThree(effectIndex, Spell)
        local plr = Spell:GetCaster()
        if(plr:HasSpell(15257) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 3)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15331) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 2)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15332) == true) then
                if(Spell:GetSpellState(3) == true) then
                        plr:CastSpell(15258)
                                                end
                                                end
                                        end
                                end
                        end
                end
        end
end
end
 
function MindBlastFour(effectIndex, Spell)
        local plr = Spell:GetCaster()
        if(plr:HasSpell(15257) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 3)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15331) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 2)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15332) == true) then
                if(Spell:GetSpellState(3) == true) then
                        plr:CastSpell(15258)
                                                end
                                                end
                                        end
                                end
                        end
                end
        end
end
end
 
function MindBlastFive(effectIndex, Spell)
        local plr = Spell:GetCaster()
    if(plr:HasSpell(15257) == true) then
		if(Spell:GetSpellState(3) == true) then
        local choice = math.random(1, 3)
			if(choice == 1) then
				plr:CastSpell(15258)
		else
			if(plr:HasSpell(15331) == true) then
				if(Spell:GetSpellState(3) == true) then
				local choice = math.random(1, 2)
                    if(choice == 1) then
						plr:CastSpell(15258)
					else
						if(plr:HasSpell(15332) == true) then
							if(Spell:GetSpellState(3) == true) then
								plr:CastSpell(15258)
                                end
                            end
                        end
                    end
                end
            end
        end
	end
end
 
function MindFlayOne(effectIndex, Spell)
        local plr = Spell:GetCaster()
        if(plr:HasSpell(15257) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 3)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15331) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 2)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15332) == true) then
                if(Spell:GetSpellState(3) == true) then
                        plr:CastSpell(15258)
                                                end
                                                end
                                        end
                                end
                        end
                end
        end
end
end

function MindFlayTwo(effectIndex, Spell)
        local plr = Spell:GetCaster()
        if(plr:HasSpell(15257) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 3)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15331) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 2)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15332) == true) then
                if(Spell:GetSpellState(3) == true) then
                        plr:CastSpell(15258)
                                                 end
                                                end
                                        end
                                end
                        end
                end
        end
end
end
 
function MindFlayThree(effectIndex, Spell)
        local plr = Spell:GetCaster()
        if(plr:HasSpell(15257) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 3)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15331) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 2)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15332) == true) then
                if(Spell:GetSpellState(3) == true) then
                        plr:CastSpell(15258)
                                                end
                                                end
                                        end
                                end
                        end
                end
        end
end
end
function MindFlayFour(effectIndex, Spell)
        local plr = Spell:GetCaster()
        if(plr:HasSpell(15257) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 3)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15331) == true) then
                if(Spell:GetSpellState(3) == true) then
                local choice = math.random(1, 2)
                        if(choice == 1) then
                        plr:CastSpell(15258)
        else
        if(plr:HasSpell(15332) == true) then
                if(Spell:GetSpellState(3) == true) then
                        plr:CastSpell(15258)
                                                end
                                                end
                                        end
                                end
                        end
                end
        end
end
end

RegisterDummySpell(10947, "MindBlastOne")
RegisterDummySpell(25372, "MindBlastTwo")
RegisterDummySpell(25375, "MindBlastThree")
RegisterDummySpell(48126, "MindBlastFour")
RegisterDummySpell(48127, "MindBlastFive")
RegisterDummySpell(18807, "MindFlayOne")
RegisterDummySpell(25387, "MindFlayTwo")
RegisterDummySpell(48155, "MindFlayThree")
RegisterDummySpell(48156, "MindFlayFour")