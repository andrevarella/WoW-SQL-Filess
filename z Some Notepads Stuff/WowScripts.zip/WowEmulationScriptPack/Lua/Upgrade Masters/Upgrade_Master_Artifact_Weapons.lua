local ID = 516540
local secondtext1 = "[REROLL]|r\n\n|TInterface\\icons\\Frostfire Orb:25:25:-15:0|t"
local text1 = "|cffff0000" .. secondtext1 .. ""
local text2 = "Burden of Eternity\n|TInterface\\icons\\Titanforge_Stone:25:25:-15:0|t"
local text3 = "Titanforge Stone\n|TInterface\\icons\\INV_Misc_Apexis_Crystal:25:25:-15:0|t"
local text5 = "Shazzian Crystals\n\n|cff000000Purchasing this will UPGRADE YOUR ARTIFACT WEAPONS!"
local color = "|cff9700FF"
local gay = {--item ID, amount,class,string,intid
{1,5141800,1,"",color .. "[675] Ulthalesh, the Deadwind Harvester " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650000},
{1,5141801,1,"",color .. "[675] The Fist of Ra-Den " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650001},
{1,5141802,1,"",color .. "[675] The Highkeeper's Ward " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650002},
{1,5141803,1,"",color .. "[675] Ebonchill " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650003},
{1,5141804,1,"",color .. "[675] Anguish " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650004},
{1,5141805,1,"",color .. "[675] Sorrow " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650005},
{1,5141806,1,"",color .. "[675] Ashbringer " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650006},
{1,5141807,1,"",color .. "[675] Apocalypse " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650007},
{1,5141808,1,"",color .. "[675] Strom'kar the Warbreaker " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650008},
{1,5141809,1,"",color .. "[675] Scythe of Elune " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650009},
{1,5141810,1,"",color .. "[675] Thas'dorah, Legacy of the Windrunners " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650010},
{1,5141811,1,"",color .. "[675] Xal'atath, Blade of the Black Empire " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650011},
{1,5141812,1,"",color .. "[675] Secrets of the Void " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650012},
{1,5141813,1,"",color .. "[675] Doomhammer " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650013},
{1,5141814,1,"",color .. "[675] Fury of the Stonemother " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650014},
{1,5141815,1,"",color .. "[675] The Silver Hand " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650015},
{1,5141816,1,"",color .. "[675] Frostreaper " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650016},
{1,5141817,1,"",color .. "[675] Icebringer " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650017},
{1,5141818,1,"",color .. "[675] Fang of Ashmane " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650018},
{1,5141819,1,"",color .. "[675] Fang of Ashmane " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650019},
{1,5141820,1,"",color .. "[675] Light's Beacon of T'uure " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650020},
{1,5141821,1,"",color .. "[675] Talonclaw " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650021},
{1,5141822,1,"",color .. "[675] Truthguard " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650022},
{1,5141823,1,"",color .. "[675] Oathguard " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650023},
{1,5141824,1,"",color .. "[675] Maw of the Damned " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650024},
{1,5141825,1,"",color .. "[675] Claw of Ursoc " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650025},
{1,5141826,1,"",color .. "[675] Claw of Ursoc " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650026},
{1,5141827,1,"",color .. "[675] Scale of the Earth Warder " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650027},
{1,5141828,1,"",color .. "[675] Scaleshard " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650028},
{1,5141829,1,"",color .. "[675] Heart of the Phoenix " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650029},
{1,5141830,1,"",color .. "[675] Felo'Melorn " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650030},
{2,5151800,1,"",color .. "[750] Ulthalesh, the Deadwind Harvester " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650100},
{2,5151801,1,"",color .. "[750] The Fist of Ra-Den " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650101},
{2,5151802,1,"",color .. "[750] The Highkeeper's Ward " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650102},
{2,5151803,1,"",color .. "[750] Ebonchill " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650103},
{2,5151804,1,"",color .. "[750] Anguish " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650104},
{2,5151805,1,"",color .. "[750] Sorrow " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650105},
{2,5151806,1,"",color .. "[750] Ashbringer " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650106},
{2,5151807,1,"",color .. "[750] Apocalypse " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650107},
{2,5151808,1,"",color .. "[750] Strom'kar the Warbreaker " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650108},
{2,5151809,1,"",color .. "[750] Scythe of Elune " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650109},
{2,5151810,1,"",color .. "[750] Thas'dorah, Legacy of the Windrunners " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650110},
{2,5151811,1,"",color .. "[750] Xal'atath, Blade of the Black Empire " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650111},
{2,5151812,1,"",color .. "[750] Secrets of the Void " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650112},
{2,5151813,1,"",color .. "[750] Doomhammer " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650113},
{2,5151814,1,"",color .. "[750] Fury of the Stonemother " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650114},
{2,5151815,1,"",color .. "[750] The Silver Hand " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650115},
{2,5151816,1,"",color .. "[750] Frostreaper " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650116},
{2,5151817,1,"",color .. "[750] Icebringer " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650117},
{2,5151818,1,"",color .. "[750] Fang of Ashmane " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650118},
{2,5151819,1,"",color .. "[750] Fang of Ashmane " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650119},
{2,5151820,1,"",color .. "[750] Light's Beacon of T'uure " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650120},
{2,5151821,1,"",color .. "[750] Talonclaw " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650121},
{2,5151822,1,"",color .. "[750] Truthguard " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650122},
{2,5151823,1,"",color .. "[750] Oathguard " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650123},
{2,5151824,1,"",color .. "[750] Maw of the Damned " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650124},
{2,5151825,1,"",color .. "[750] Claw of Ursoc " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650125},
{2,5151826,1,"",color .. "[750] Claw of Ursoc " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650126},
{2,5151827,1,"",color .. "[750] Scale of the Earth Warder " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650127},
{2,5151828,1,"",color .. "[750] Scaleshard " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650128},
{2,5151829,1,"",color .. "[750] Heart of the Phoenix " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650129},
{2,5151830,1,"",color .. "[750] Felo'Melorn " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650130},
{3,5161800,1,"",color .. "[800] Ulthalesh, the Deadwind Harvester " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650200},
{3,5161801,1,"",color .. "[800] The Fist of Ra-Den " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650201},
{3,5161802,1,"",color .. "[800] The Highkeeper's Ward " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650202},
{3,5161803,1,"",color .. "[800] Ebonchill " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650203},
{3,5161804,1,"",color .. "[800] Anguish " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650204},
{3,5161805,1,"",color .. "[800] Sorrow " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650205},
{3,5161806,1,"",color .. "[800] Ashbringer " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650206},
{3,5161807,1,"",color .. "[800] Apocalypse " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650207},
{3,5161808,1,"",color .. "[800] Strom'kar the Warbreaker " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650208},
{3,5161809,1,"",color .. "[800] Scythe of Elune " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650209},
{3,5161810,1,"",color .. "[800] Thas'dorah, Legacy of the Windrunners " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650210},
{3,5161811,1,"",color .. "[800] Xal'atath, Blade of the Black Empire " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650211},
{3,5161812,1,"",color .. "[800] Secrets of the Void " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650212},
{3,5161813,1,"",color .. "[800] Doomhammer " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650213},
{3,5161814,1,"",color .. "[800] Fury of the Stonemother " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650214},
{3,5161815,1,"",color .. "[800] The Silver Hand " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650215},
{3,5161816,1,"",color .. "[800] Frostreaper " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650216},
{3,5161817,1,"",color .. "[800] Icebringer " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650217},
{3,5161818,1,"",color .. "[800] Fang of Ashmane " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650218},
{3,5161819,1,"",color .. "[800] Fang of Ashmane " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650219},
{3,5161820,1,"",color .. "[800] Light's Beacon of T'uure " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650220},
{3,5161821,1,"",color .. "[800] Talonclaw " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650221},
{3,5161822,1,"",color .. "[800] Truthguard " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650222},
{3,5161823,1,"",color .. "[800] Oathguard " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650223},
{3,5161824,1,"",color .. "[800] Maw of the Damned " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650224},
{3,5161825,1,"",color .. "[800] Claw of Ursoc " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650225},
{3,5161826,1,"",color .. "[800] Claw of Ursoc " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650226},
{3,5161827,1,"",color .. "[800] Scale of the Earth Warder " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650227},
{3,5161828,1,"",color .. "[800] Scaleshard " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650228},
{3,5161829,1,"",color .. "[800] Heart of the Phoenix " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650229},
{3,5161830,1,"",color .. "[800] Felo'Melorn " .. text1 .. "1 " .. text2 .. "5 " .. text3 .. "500,000 " .. text5 .. "|r",6650230}
}
function tierUpgradeCheck5000(player,tiernum5000)
local check15000 = false
local check25000 = false
local check35000 = false
local check15000icon = "|TInterface\\icons\\Frostfire Orb:25:25:-15:0|t"
local check25000icon = "|TInterface\\icons\\Titanforge_Stone:25:25:-15:0|t"
local check35000icon = "|TInterface\\icons\\INV_Misc_Apexis_Crystal:25:25:-15:0|t"

if tiernum5000 == 1 then
	if player:HasItem(577777, 1) then
		check15000 = true
	end
	if player:HasItem(649285, 5) then
		check25000 = true
	end
	if player:HasItem(6460050, 500) then
		check35000 = true
	end
elseif tiernum5000 == 2 then
	if player:HasItem(577777, 2) then
		check15000 = true
	end
	if player:HasItem(649285, 5) then
		check25000 = true
	end
	if player:HasItem(6460050, 1000) then
		check35000 = true
	end
elseif tiernum5000 == 3 then
	if player:HasItem(577777, 3) then
		check15000 = true
	end
	if player:HasItem(649285, 5) then
		check25000 = true
	end
	if player:HasItem(6460050, 2000) then
		check35000 = true
	end
elseif tiernum5000 == 4 then
	if player:HasItem(577777, 4) then
		check15000 = true
	end
	if player:HasItem(649285, 10) then
		check25000 = true
	end
	if player:HasItem(6460050, 5000) then
		check35000 = true
	end
elseif tiernum5000 == 5 then
	if player:HasItem(577777, 5) then
		check15000 = true
	end
	if player:HasItem(649285, 10) then
		check25000 = true
	end
	if player:HasItem(6460050, 10000) then
		check35000 = true
	end
end

if (check15000==false or check25000==false or check35000==false) then
	local check15000amount = player:GetItemCount(577777)
	local check25000amount = player:GetItemCount(649285)
	local check35000amount = player:GetItemCount(6460050)
	localsend5000 = ""
	local localsend5000 = "You do not have the materials required for this upgrade.\n\n"
	if tiernum5000 == 1 then
		if check15000amount < 1 then
			localsend5000 = localsend5000 .. check15000icon .. (1 - check15000amount) .. " Burden of Eternity\n"
		end
		if check25000amount < 5 then
			localsend5000 = localsend5000 .. check25000icon .. (5 - check25000amount) .. " Titanforge Stone\n"
		end
		if check35000amount < 500 then
			localsend5000 = localsend5000 .. check35000icon .. (500 - check35000amount) .. " Shazzian Shards (1000)\n"
		end
		player:SendBroadcastMessage(localsend5000)
	elseif tiernum5000 == 2 then
		if check15000amount < 2 then
			localsend5000 = localsend5000 .. check15000icon .. (2 - check15000amount) .. " Burden of Eternity\n"
		end
		if check25000amount < 5 then
			localsend5000 = localsend5000 .. check25000icon .. (5 - check25000amount) .. " Titanforge Stone\n"
		end
		if check35000amount < 1000 then
			localsend5000 = localsend5000 .. check35000icon .. (1000 - check35000amount) .. " Shazzian Shards (1000)\n"
		end
		player:SendBroadcastMessage(localsend5000)
	elseif tiernum5000 == 3 then
		if check15000amount < 3 then
			localsend5000 = localsend5000 .. check15000icon .. (3 - check15000amount) .. " Burden of Eternity\n"
		end
		if check25000amount < 5 then
			localsend5000 = localsend5000 .. check25000icon .. (5 - check25000amount) .. " Titanforge Stone\n"
		end
		if check35000amount < 2000 then
			localsend5000 = localsend5000 .. check35000icon .. (2000 - check35000amount) .. " Shazzian Shards (1000)\n"
		end
		player:SendBroadcastMessage(localsend5000)
	elseif tiernum5000 == 4 then
		if check15000amount < 4 then
			localsend5000 = localsend5000 .. check15000icon .. (4 - check15000amount) .. " Burden of Eternity\n"
		end
		if check25000amount < 10 then
			localsend5000 = localsend5000 .. check25000icon .. (10 - check25000amount) .. " Titanforge Stone\n"
		end
		if check35000amount < 5000 then
			localsend5000 = localsend5000 .. check35000icon .. (5000 - check35000amount) .. " Shazzian Shards (1000)\n"
		end
		player:SendBroadcastMessage(localsend5000)
    elseif tiernum5000 == 5 then
        if check15000amount < 5 then
            localsend5000 = localsend5000 .. check15000icon .. (5 - check15000amount) .. " Burden of Eternity\n"
        end
        if check25000amount < 10 then
            localsend5000 = localsend5000 .. check25000icon .. (10 - check25000amount) .. " Titanforge Stone\n"
        end
        if check35000amount < 10000 then
            localsend5000 = localsend5000 .. check35000icon .. (10000 - check35000amount) .. " Shazzian Shards (1000)\n"
        end
        player:SendBroadcastMessage(localsend5000)
    end
	return false
end
    return true
end

function onGossip5000(event, player, unit)
	for i in ipairs(gay) do
		if (player:HasItem(gay[i][2],gay[i][3])) then
			player:GossipMenuAddItem(0,gay[i][5], 0, gay[i][6])
		end
	end
	player:GossipSendMenu(105, unit)
end

function onSelect5000(event, player, unit, sender, intid, code, id)
	for i in pairs(gay) do
		if(gay[i][6] == intid) then
			if(tierUpgradeCheck5000(player,gay[i][1])) then
			local tiernum5000 = gay[i][1]
			if (tiernum5000 == 1) then
				player:RemoveItem(577777, 1)
				player:RemoveItem(649285, 5)
				player:RemoveItem(6460050, 500)
			elseif (tiernum5000 == 2) then
				player:RemoveItem(577777, 2)
				player:RemoveItem(649285, 5)
				player:RemoveItem(6460050, 1000)
			elseif (tiernum5000 == 3) then
				player:RemoveItem(577777, 3)
				player:RemoveItem(649285, 5)
				player:RemoveItem(6460050, 2000)
			elseif (tiernum5000 == 4) then
				player:RemoveItem(577777, 4)
				player:RemoveItem(649285, 10)
				player:RemoveItem(6460050, 5000)
			elseif (tiernum5000 == 5) then
				player:RemoveItem(577777, 5)
				player:RemoveItem(649285, 10)
				player:RemoveItem(6460050, 10000)
			end
			player:RemoveItem(gay[i][2], gay[i][3])
				local newItem = gay[i][2]+10000
				player:AddItem(newItem, 1)
			end
		end
	end
	player:GossipComplete()
end

RegisterCreatureGossipEvent(ID, 1, onGossip5000)
RegisterCreatureGossipEvent(ID, 2, onSelect5000)