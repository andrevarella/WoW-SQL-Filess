CREATE TABLE IF NOT EXISTS world.heirloom_list (
    CharID int(10) unsigned
);

UPDATE `creature_template` set `modelid1` = 31803 where `entry` = 32568;
UPDATE `creature_template` set `modelid2` = 17722 where `entry` = 32568;
UPDATE `creature_template` set `modelid3` = 31958 where `entry` = 32568;
UPDATE `creature_template` set `modelid4` = 28040 where `entry` = 32568;